def Hello_world();
print("Hello world")

hello_world